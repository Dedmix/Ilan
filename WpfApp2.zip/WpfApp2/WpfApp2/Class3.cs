﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp2
{
    public class Filt
    {
        public bool FiltClass;
        public string FiltName { get; set; }
    }
}
